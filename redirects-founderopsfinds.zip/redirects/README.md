# FounderOpsFinds — Redirect Links

Deploy these files to get clean redirect URLs for your Notion templates.

## Your redirect URLs (after deployment)

| Product | Redirect URL |
|---------|-------------|
| HR & People Ops OS | https://founderopsfinds.github.io/r/hr-ops |
| Pulse Survey & eNPS | https://founderopsfinds.github.io/r/pulse-survey |
| Offer Letter Templates | https://founderopsfinds.github.io/r/offer-letter |
| PIP & PDP Toolkit | https://founderopsfinds.github.io/r/pip-pdp |
| Startup Company OS | https://founderopsfinds.github.io/r/startup-os |

## Option A: GitHub Pages (recommended — FREE, takes 3 minutes)

1. Go to github.com → New repository → Name it `r` → Public
2. Upload the entire `r/` folder
3. Go to Settings → Pages → Source: main branch → Save
4. Your links are live at `https://founderopsfinds.github.io/r/[product]`

## Option B: Netlify Drop (instant, no account needed)

1. Go to netlify.com/drop
2. Drag the entire `r/` folder onto the page
3. You get a URL like `https://[random].netlify.app/hr-ops`
4. (Optional) Create a free account to get a custom subdomain

## To update a destination URL

Just edit the `index.html` file in the product folder and push the change.
No need to re-issue PDFs — the redirect handles it.
